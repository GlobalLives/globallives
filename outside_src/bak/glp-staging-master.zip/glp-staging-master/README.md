# A Video Library of Life Experience

## About the Global Lives Project

The Global Lives Project is a video library of life experience. A nonprofit, volunteer-driven effort of filmmakers and translators, we create and curate films that capture 24 continuous hours in the life of individuals from around the world. We use visual media to cultivate the ethics of global citizenship and cross-cultural empathy for a global audience.